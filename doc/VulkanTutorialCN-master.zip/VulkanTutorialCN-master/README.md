# VulkanTutorialCN
Vulkan中文教程v0.9

原文地址：https://vulkan-tutorial.com/

译文PDF地址：https://github.com/fangcun010/VulkanTutorialCN/blob/master/Vulkan%E7%BC%96%E7%A8%8B%E6%8C%87%E5%8D%97.pdf

由于本人才疏学浅，翻译难免有误，望各位不吝惜指正。
